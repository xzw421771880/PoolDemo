//
//  ViewController.m
//  PoolDemo
//
//  Created by Dxc_iOS on 2018/4/10.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "ViewController.h"
#import "buSerach.h"

@interface ViewController ()
{
    buSerach *tanChuang;
    UITextField *ttt;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    ttt=[[UITextField alloc]initWithFrame:Frame(10, 50, WIDTH-70, 30)];
    ttt.backgroundColor=[UIColor grayColor];
    ttt.placeholder=@"请输入弹出格子个数";
    [self.view addSubview:ttt];
    
    UILabel *la=[[UILabel alloc]initWithFrame:Frame(WIDTH-50, 50, 40, 30)];
    la.text=@"确认";
    la.backgroundColor=[UIColor grayColor];
    [self.view addSubview:la];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    la.userInteractionEnabled=YES;
    [la addGestureRecognizer:tap];
    
    
    tanChuang=[[buSerach alloc]initWithFrame:Frame(0, 90, WIDTH, HEIGHT-100)];
    [self.view addSubview:tanChuang];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)tapAction:(UITapGestureRecognizer *)sender
{
    [tanChuang addGezi:[ttt.text integerValue]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
