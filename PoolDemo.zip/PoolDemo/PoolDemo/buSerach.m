//
//  buSerach.m
//  replenishment
//
//  Created by Dxc_iOS on 2018/3/23.
//  Copyright © 2018年 肖中旺. All rights reserved.
//

#import "buSerach.h"

@implementation buSerach

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self addAllViews];
    
        self.backgroundColor=RGB(230, 230, 230);
    }
    return self;
}

- (void)addAllViews
{
    
}

-(void)addGezi:(NSInteger )count
{
    //移除子视图
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    for (int i=0; i<count; i++) {
        UIView *gezi=[[UIView alloc]initWithFrame:Frame(0, 20*i, self.frame.size.width, 15)];
        gezi.backgroundColor=[UIColor redColor];
        [self addSubview:gezi];
    }
    self.frame=Frame(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, 20*count);
}

@end
